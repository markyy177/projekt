<?php
require_once("kapcsolat.php");
require_once("auth.php");
echo"szia, ".$_SESSION["user"];
?>